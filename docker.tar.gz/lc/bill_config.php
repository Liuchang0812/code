<?php
date_default_timezone_set("Etc/GMT-8");

$fields = array(
    'std_storage'   =>  array(
        'pid'       => '12675',
        'pid_name'  => 'tce_cos_std_storage',
        'unit_key'  => 'GB',
        'cid'       => '101409',
    ),
    'std_req_r'      =>  array(
        'pid'       => '12676',
        'pid_name'  => 'tce_cos_std_req_r',
        'unit_key'  => 'WC',
        'cid'       => '101410',
    ),
    'std_req_w'     =>  array(
        'pid'       => '12677',
        'pid_name'  => 'tce_cos_std_req_w',
        'unit_key'  => 'WC',
        'cid'       => '101411',
    ),
    'out_flux'   =>  array(
        'pid'       => '12678',
        'pid_name'  => 'tce_cos_flux',
        'unit_key'  => 'GB',
        'cid'       => '101412',
    ),
);

$regionid = "50000019";
$zoneid = "50190001";

$db_host    = getenv("db_host")?getenv("db_host"):"100.99.42.13";
$db_port    = getenv("db_port")?getenv("db_port"):"3306";
$db_user    = getenv("db_user")?getenv("db_user"):"tceuser";
$db_passwd  = getenv("db_passwd")?getenv("db_passwd"):"tceuser";
$db_db      = getenv("db_db")?getenv("db_db"):"tceDb";
$bill_db = new mysqli($db_host, $db_user, $db_passwd, $db_db, $db_port);
if(mysqli_connect_errno()){
    echo "DB connect fail, try again!\n";
    exit;
}
$bill_db->query('set names utf8');

//host 10.251.52.10 yhgz.billing.tencentyun.com
//host 10.251.52.10 yhcq.billing.tencentyun.com
$url = getenv("bill_api_url")?getenv("bill_api_url"):"http://yhgz.billing.tencentyun.com/feev2/sendResource.php";
$sendResource = curl_init($url);
curl_setopt($sendResource, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($sendResource, CURLOPT_POST, 1);

$date = date('Y-m-d');
$calc_date_daily = date('Ymd');
$yesterday = date('Y-m-d', strtotime($date . ' -1 day'));
$start_time_daily = date('Y-m-d 00:00:00', strtotime($yesterday));
$end_time_daily = date('Y-m-d 23:59:59', strtotime($yesterday));

$limit = 10;//每次推送记录条数

function microtime_format()
{   
    $mtime = microtime(true);
    $sec = floor($mtime);
    $msec = $mtime-$sec;
    $date = date('Y-m-d H:i:s',$sec);
    return $date.".".round($msec,3);
}

function _log($msg)
{
    echo '['.microtime_format().']'.$msg."\n";
}
