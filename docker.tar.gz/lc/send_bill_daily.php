<?php
include_once 'bill_config.php';

$total_cnt = 0;
$sql = "select count(1) as totalcnt from tce_daily_uin_region where date = '".$yesterday."' and status <> 1";
_log($sql);
$ret = $bill_db->query($sql);
$info = $ret->fetch_assoc();
if(!empty($info)) {
    $total_cnt = $info['totalcnt'];
}
$ret->free();
_log($total_cnt);

while($total_cnt) {
    for ($idx = 0; $idx < $total_cnt;) {
        $uins = array();
        $ids = array();

        foreach ($fields as $field => $value) {
            $data[$field] = array(
                'cid'           => $value['cid'],
                'calcDate'      => $calc_date_daily,
                'data'          => array(),
            );
        }

        $ret = $bill_db->query("select id,uin,std_storage/1024 as std_storage,std_req_r/10000 as std_req_r,std_req_w/10000 as std_req_w,in_flux/1000000000 as in_flux, out_flux/1000000000 as out_flux from tce_daily_uin_region where date = '$yesterday' and status <> 1 limit $limit");
        if ($ret) {
            while ($info = $ret->fetch_assoc()) {
                $id = $info['id'];
                $uin = $info['uin'];
                _log('id['.$id.'] uin['.$uin.'] std_storage['.$info['std_storage'].'] std_req_r['.$info['std_req_r'].'] std_req_w['.$info['std_req_w'].'] in_flux['.$info['in_flux'].'] out_flux['.$info['out_flux'].']');
                $ids[] = $id;
                $uins[] = $uin;

                foreach ($fields as $field => $value) {
                    $amount = $info[$field];

                    if($amount > 0) {
                        $params = array(
                            'componentKey'      =>  $value['pid_name'],
                            'count'             =>  sprintf('%.5f',$amount),
                            'countUnitKey'      =>  $value['unit_key'],
                        );
                        $data_info = array(
                            'serialId'      => $uin.'-'.$value['pid_name'],
                            'uin'           => $uin,
                            'appId'         => $uin,
                            'platform'      => '1',         //qcloud
                            'projectId'     => '0',         //不支持
                            'regionId'      => $regionid,
                            'zoneId'        => $zoneid,
                            'payMode'       => '0',         //后付费
                            'pid'           => $value['pid'],
                            'actId'         => '',          //不填
                            'calcDate'      => $calc_date_daily,
                            'startTime'     => $start_time_daily,
                            'endTime'       => $end_time_daily,
                            'calcNum'       => '1',         //默认值
                            'timeSpan'      => '1',         //默认值
                            'params'        => json_encode($params),
                            'dataStatus'    => '0',         //正常推送
                            'parts'         => json_encode(array($value['pid_name']=>sprintf('%.5f',$amount))),
                        );
                        if(!isset($data[$field]['data'][$uin]))
                            $data[$field]['data'][$uin] = array();
                        $data[$field]['data'][$uin][] = $data_info;
                    }
                }
            }

            $uins_str = "'".implode("','",$uins)."'";
            $ids_str = implode(",",$ids);

            // _log("data[".json_encode($data)."]");

            $success_count = 0;

            foreach ($data as $field => $sub_data) {
                _log("sub_data[".json_encode($sub_data)."]");

                if(!empty($sub_data['data'])){
                    curl_setopt($sendResource, CURLOPT_POSTFIELDS, json_encode($sub_data));
                    $output = curl_exec($sendResource);
                    _log("output[".$output."]");
                    if (empty($output)) {
                        usleep(20000);
                        $output = curl_exec($sendResource);
                    }

                    if (!empty($output)) {
                        $outputjson = json_decode($output, true);
                        if(isset($outputjson['retCode']) and 0 == $outputjson['retCode']) {//success
                            $success_count += 1;
                            continue;
                        }
                    }

                    //fail
                    $bill_db->query("update tce_daily_uin_region set status = 2 where id in ($ids_str)");
                    $msg = date('Y-m-d H:i:s').' Send bill fail, ids['.$ids_str.'], field['.$field.'], uins['.$uins_str.'], $output['.$output."]\n";
                    file_put_contents(date('Ymd').'.log', '['.microtime_format().']'.$msg, FILE_APPEND);
                    break;
                } else {
                    $success_count += 1;
                }
            }

            if($success_count == count($data)){
                $bill_db->query("update tce_daily_uin_region set status = 1 where id in ($ids_str)");
            }
        }

        $idx += $limit;
    }

    //如果还有没有推送成功的，重试
    $sql = "select count(1) as totalcnt from tce_daily_uin_region where date = '".$yesterday."' and status <> 1";
    _log($sql);
    $ret = $bill_db->query($sql);
    $info = $ret->fetch_assoc();
    if(!empty($info)) {
        $total_cnt = $info['totalcnt'];
    }
    $ret->free();
    _log($total_cnt);
}
