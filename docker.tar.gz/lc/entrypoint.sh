#!/bin/bash
set -x
env >> /etc/default/locale
/etc/init.d/cron start
crontab -l
/etc/init.d/cron status
tail -f /var/log/moira.log
